package com.example

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.SvgDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.data.FirebaseSyncManager
import com.example.data.RezkaDatabase
import com.example.data.RezkaRepository
import com.example.data.RezkaService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RezkaApplication : Application(), ImageLoaderFactory {
    companion object {
        lateinit var instance: RezkaApplication
            private set
    }

    val database by lazy { RezkaDatabase.getDatabase(this) }
    val repository by lazy { RezkaRepository(database) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        com.example.ui.haptics.HapticEngine.init(this)
        com.example.data.NetworkMonitor.init(this)
        RezkaService.init(this)
        FirebaseSyncManager.init(this, repository)
        com.example.data.SeriesUpdateEngine.createNotificationChannel(this)
        
        // Мгновенное создание и инициализация текстового лог-файла проверок сериалов
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            com.example.data.SeriesUpdateLogger.init(this@RezkaApplication)
        }
    }

    /**
     * Высокопроизводительный загрузчик изображений Coil с кэшированием в памяти и на диске,
     * аппаратными битмапами для GPU (allowHardware) и обходом блокировок.
     */
    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .okHttpClient { RezkaService.imageOkHttpClient }
            .components {
                add(SvgDecoder.Factory())
            }
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .strongReferencesEnabled(true)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(250L * 1024 * 1024) // 250 MB расширенный кэш
                    .build()
            }
            .crossfade(150)
            .allowHardware(true)
            .respectCacheHeaders(false)
            .build()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_MODERATE) {
            com.example.data.ImagePreloaderEngine.clearCache()
        }
    }
}
